<!DOCTYPE html>
<?php
	include 'auth.php';
?>
<html lang = "eng">
	<head>
		<title>Simple Employee Attendance Record System</title>
		<?php include 'header.php'; ?>
	</head>
	<body>
		<?php include 'nav_bar.php' ?>
		<div class = "container-fluid admin" >
			
			<div class = "alert alert-primary">Dashboard</div>
			<h5>Welcome <?php echo ucwords($user_name) ?> !</h5>
			</div>
		</div>
	</body>
	
	
</html>